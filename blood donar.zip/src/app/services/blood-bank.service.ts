import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BLOOD_TYPES, type BloodType } from '../constants/blood-types';
import type { Donor } from '../models/donor';
import { emptyStock, type BloodStock } from '../models/blood-stock';

const DONORS_KEY = 'bb_donors_v1';
const STOCK_KEY = 'bb_stock_v1';

function loadDonors(): Donor[] {
  try {
    const raw = localStorage.getItem(DONORS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Donor[];
    return parsed.map((d) => ({ ...d }));
  } catch {
    return [];
  }
}

function saveDonors(donors: Donor[]) {
  localStorage.setItem(DONORS_KEY, JSON.stringify(donors));
}

function loadStock(): BloodStock {
  try {
    const raw = localStorage.getItem(STOCK_KEY);
    if (!raw) return emptyStock();
    const parsed = JSON.parse(raw) as Partial<BloodStock>;
    const base = emptyStock();
    (Object.keys(base) as BloodType[]).forEach((t) => {
      base[t] = Math.max(0, Math.trunc((parsed[t] ?? 0) as number));
    });
    return base;
  } catch {
    return emptyStock();
  }
}

function saveStock(stock: BloodStock) {
  localStorage.setItem(STOCK_KEY, JSON.stringify(stock));
}

@Injectable({ providedIn: 'root' })
export class BloodBankService {
  private http = inject(HttpClient);
  donors = signal<Donor[]>(loadDonors());
  stock = signal<BloodStock>(loadStock());
  private remote = signal(false);

  constructor() {
    // Try to bootstrap from backend if available
    this.http.get<BackendDonor[]>('/api/donors').subscribe({
      next: (rows) => {
        const mapped = rows.map(fromBackend);
        this.donors.set(mapped);
        saveDonors(mapped);
        this.remote.set(true);
      },
      error: () => {
        this.remote.set(false);
      },
    });
  }

  addDonor(input: Omit<Donor, 'id'>): Donor {
    if (this.remote()) {
      const payload = toBackend({ ...input, id: '' } as Donor);
      // eslint-disable-next-line rxjs/no-ignored-subscription
      this.http.post<BackendDonor>('/api/donors', payload).subscribe({
        next: (row) => {
          const donor = fromBackend(row);
          const next = [donor, ...this.donors()];
          this.donors.set(next);
          saveDonors(next);
        },
      });
      // Optimistic UI
      return { ...input, id: crypto.randomUUID() } as Donor;
    }
    const donor: Donor = { ...input, id: crypto.randomUUID() };
    const next = [donor, ...this.donors()];
    this.donors.set(next);
    saveDonors(next);
    return donor;
  }

  updateDonor(id: string, patch: Partial<Omit<Donor, 'id'>>): Donor | null {
    let updated: Donor | null = null;
    const next = this.donors().map((d) => {
      if (d.id !== id) return d;
      updated = { ...d, ...patch } as Donor;
      return updated;
    });
    if (updated) {
      this.donors.set(next);
      saveDonors(next);
    }
    return updated;
  }

  removeDonor(id: string) {
    const next = this.donors().filter((d) => d.id !== id);
    this.donors.set(next);
    saveDonors(next);
  }

  getStockOf(type: BloodType) {
    return this.stock()[type] ?? 0;
  }

  setStock(type: BloodType, units: number) {
    const clamped = Math.max(0, Math.trunc(units));
    const next = { ...this.stock(), [type]: clamped } as BloodStock;
    this.stock.set(next);
    saveStock(next);
  }

  increment(type: BloodType, delta = 1) {
    this.setStock(type, (this.stock()[type] ?? 0) + delta);
  }

  decrement(type: BloodType, delta = 1) {
    this.setStock(type, (this.stock()[type] ?? 0) - delta);
  }

  donorsSorted(sort: 'lastDonation' | 'bloodGroup' | 'name' = 'lastDonation') {
    const arr = [...this.donors()];
    if (sort === 'bloodGroup') {
      const order = new Map(BLOOD_TYPES.map((t, i) => [t, i] as const));
      arr.sort((a, b) => (order.get(a.bloodGroup)! - order.get(b.bloodGroup)! || a.name.localeCompare(b.name)));
    } else if (sort === 'name') {
      arr.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      arr.sort((a, b) => new Date(b.lastDonationDate).getTime() - new Date(a.lastDonationDate).getTime());
    }
    return arr;
  }

  filterByGroup(group: BloodType | 'ALL') {
    if (group === 'ALL') return this.donors();
    return this.donors().filter((d) => d.bloodGroup === group);
  }
}

// Backend wiring
type BackendGroup = 'A_POS' | 'A_NEG' | 'B_POS' | 'B_NEG' | 'O_POS' | 'O_NEG' | 'AB_POS' | 'AB_NEG';

interface BackendDonor {
  id: number;
  name: string;
  bloodGroup: BackendGroup;
  phoneNumber: string;
  area: string;
  healthCondition?: string;
  age: number;
  lastDonationDate?: string | null; // YYYY-MM-DD
  createdAt?: string;
  updatedAt?: string;
}

function toBackendGroup(g: BloodType): BackendGroup {
  switch (g) {
    case 'A+': return 'A_POS';
    case 'A-': return 'A_NEG';
    case 'B+': return 'B_POS';
    case 'B-': return 'B_NEG';
    case 'O+': return 'O_POS';
    case 'O-': return 'O_NEG';
    case 'AB+': return 'AB_POS';
    case 'AB-': return 'AB_NEG';
  }
}

function fromBackendGroup(g: BackendGroup): BloodType {
  switch (g) {
    case 'A_POS': return 'A+';
    case 'A_NEG': return 'A-';
    case 'B_POS': return 'B+';
    case 'B_NEG': return 'B-';
    case 'O_POS': return 'O+';
    case 'O_NEG': return 'O-';
    case 'AB_POS': return 'AB+';
    case 'AB_NEG': return 'AB-';
  }
}

function fromBackend(d: BackendDonor): Donor {
  return {
    id: String(d.id),
    name: d.name,
    age: d.age,
    contactNumber: d.phoneNumber,
    address: d.area,
    bloodGroup: fromBackendGroup(d.bloodGroup),
    lastDonationDate: d.lastDonationDate ?? new Date().toISOString(),
    notes: d.healthCondition ?? '',
  };
}

function toBackend(d: Donor): Omit<BackendDonor, 'id'> {
  return {
    name: d.name,
    bloodGroup: toBackendGroup(d.bloodGroup),
    phoneNumber: d.contactNumber,
    area: d.address,
    healthCondition: d.notes ?? '',
    age: d.age,
    lastDonationDate: (d.lastDonationDate ?? '').slice(0, 10) || null,
  } as Omit<BackendDonor, 'id'>;
}
