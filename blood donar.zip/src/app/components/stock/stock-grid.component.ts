import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BloodBankService } from '../../services/blood-bank.service';
import { BLOOD_TYPES, type BloodType } from '../../constants/blood-types';

@Component({
  selector: 'app-stock-grid',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section>
      <div class="flex items-center justify-between mb-3">
        <h2 class="text-lg font-semibold text-slate-800">Current Blood Stock</h2>
        <div class="text-sm text-slate-500">Click + or - to adjust units</div>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        <div *ngFor="let t of types" class="rounded-xl bg-white/80 border border-slate-200/70 shadow-sm p-4">
          <div class="flex items-center justify-between">
            <div>
              <div class="text-slate-500 text-xs">Type</div>
              <div class="text-xl font-bold tracking-tight">{{ t }}</div>
            </div>
            <div class="flex items-center gap-2">
              <button class="btn btn-icon" (click)="dec(t)">−</button>
              <div class="text-2xl font-semibold tabular-nums" [class.text-amber-600]="stock()[t] === 0" [class.text-emerald-600]="stock()[t] > 0">{{ stock()[t] }}</div>
              <button class="btn btn-icon" (click)="inc(t)">+</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class StockGridComponent {
  private bb = inject(BloodBankService);
  types: BloodType[] = BLOOD_TYPES;
  stock = this.bb.stock;

  inc(t: BloodType) { this.bb.increment(t, 1); }
  dec(t: BloodType) { this.bb.decrement(t, 1); }
}
