import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { BLOOD_TYPES, type BloodType } from '../../constants/blood-types';
import { BloodBankService } from '../../services/blood-bank.service';
import { toISODateInput } from '../../utils/date';

@Component({
  selector: 'app-donor-form',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  template: `
    <section>
      <h2 class="text-lg font-semibold text-slate-800 mb-3">Add New Donor</h2>
      <form [formGroup]="form" (ngSubmit)="submit()" class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label class="label">Full Name</label>
          <input class="field" type="text" formControlName="name" required placeholder="e.g., Priya Sharma" />
        </div>
        <div>
          <label class="label">Age</label>
          <input class="field" type="number" formControlName="age" required min="18" max="65" />
        </div>
        <div>
          <label class="label">Contact Number</label>
          <input class="field" type="tel" formControlName="contactNumber" required placeholder="+1 555-0123" />
        </div>
        <div>
          <label class="label">Address</label>
          <input class="field" type="text" formControlName="address" required placeholder="City, State" />
        </div>
        <div>
          <label class="label">Blood Group</label>
          <select class="field" formControlName="bloodGroup" required>
            <option *ngFor="let t of types" [ngValue]="t">{{ t }}</option>
          </select>
        </div>
        <div>
          <label class="label">Last Donation Date</label>
          <input class="field" type="date" formControlName="lastDonationDate" required />
        </div>
        <div class="md:col-span-2">
          <label class="label">Health Condition</label>
          <textarea class="field" rows="2" formControlName="notes" placeholder="e.g., Healthy, Diabetic (controlled)"></textarea>
        </div>
        <div class="md:col-span-2 flex items-center gap-3">
          <button class="btn-primary" type="submit" [disabled]="form.invalid">Add Donor</button>
          <div class="text-sm text-emerald-700" *ngIf="added()">Donor added successfully.</div>
        </div>
      </form>
    </section>
  `,
})
export class DonorFormComponent {
  private fb = inject(FormBuilder);
  private bb = inject(BloodBankService);

  types: BloodType[] = BLOOD_TYPES;
  added = signal(false);

  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    age: [25, [Validators.required, Validators.min(18), Validators.max(65)]],
    contactNumber: ['', [Validators.required, Validators.minLength(7)]],
    address: ['', [Validators.required]],
    bloodGroup: this.types[0] as BloodType,
    lastDonationDate: toISODateInput(new Date()),
    notes: [''],
  });

  submit() {
    if (this.form.invalid) return;
    const v = this.form.getRawValue();
    this.bb.addDonor({
      name: v.name,
      age: v.age,
      contactNumber: v.contactNumber,
      address: v.address,
      bloodGroup: v.bloodGroup,
      lastDonationDate: new Date(v.lastDonationDate).toISOString(),
      notes: v.notes ?? '',
    });
    this.added.set(true);
    setTimeout(() => this.added.set(false), 2000);
    this.form.patchValue({
      name: '',
      contactNumber: '',
      address: '',
      notes: '',
    });
  }
}
