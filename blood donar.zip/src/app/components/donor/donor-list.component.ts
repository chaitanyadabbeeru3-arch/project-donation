import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BloodBankService } from '../../services/blood-bank.service';
import { BLOOD_TYPES, type BloodType } from '../../constants/blood-types';
import { formatDate } from '../../utils/date';

@Component({
  selector: 'app-donor-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section>
      <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
        <h2 class="text-lg font-semibold text-slate-800">Registered Donors</h2>
        <div class="flex flex-wrap items-center gap-2">
          <select class="field !h-9" [(ngModel)]="group" (ngModelChange)="noop()">
            <option [ngValue]="'ALL'">All Groups</option>
            <option *ngFor="let t of types" [ngValue]="t">{{ t }}</option>
          </select>
          <select class="field !h-9" [(ngModel)]="sort">
            <option [ngValue]="'lastDonation'">Sort: Last Donation</option>
            <option [ngValue]="'bloodGroup'">Sort: Blood Group</option>
            <option [ngValue]="'name'">Sort: Name</option>
          </select>
        </div>
      </div>

      <div class="overflow-x-auto rounded-xl border border-slate-200 shadow-sm bg-white/80">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-slate-50 text-slate-600">
            <tr>
              <th class="px-4 py-3 font-semibold">Name</th>
              <th class="px-4 py-3 font-semibold">Blood Group</th>
              <th class="px-4 py-3 font-semibold">Last Donation</th>
              <th class="px-4 py-3 font-semibold">Age</th>
              <th class="px-4 py-3 font-semibold">Contact</th>
              <th class="px-4 py-3 font-semibold">Address</th>
              <th class="px-4 py-3 font-semibold w-10"></th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let d of view()" class="border-t border-slate-100">
              <td class="px-4 py-3 font-medium text-slate-900">{{ d.name }}</td>
              <td class="px-4 py-3">
                <span class="inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-semibold"
                      [class.bg-rose-50]="true" [class.text-rose-700]="true" [class.border-rose-200]="true">{{ d.bloodGroup }}</span>
              </td>
              <td class="px-4 py-3 text-slate-700">{{ fmt(d.lastDonationDate) }}</td>
              <td class="px-4 py-3 text-slate-700 tabular-nums">{{ d.age }}</td>
              <td class="px-4 py-3 text-slate-700">{{ d.contactNumber }}</td>
              <td class="px-4 py-3 text-slate-700">{{ d.address }}</td>
              <td class="px-4 py-3 text-right">
                <button class="text-rose-700 hover:underline" (click)="remove(d.id)">Remove</button>
              </td>
            </tr>
            <tr *ngIf="view().length === 0">
              <td class="px-4 py-8 text-center text-slate-500" colspan="7">No donors match your filters.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  `,
})
export class DonorListComponent {
  private bb = inject(BloodBankService);
  types: BloodType[] = BLOOD_TYPES;
  group = signal<BloodType | 'ALL'>('ALL');
  sort = signal<'lastDonation' | 'bloodGroup' | 'name'>('lastDonation');

  view = computed(() => {
    const g = this.group();
    const s = this.sort();
    const base = g === 'ALL' ? this.bb.donors() : this.bb.donors().filter((d) => d.bloodGroup === g);
    if (s === 'bloodGroup') {
      const order = new Map(this.types.map((t, i) => [t, i] as const));
      return [...base].sort((a, b) => order.get(a.bloodGroup)! - order.get(b.bloodGroup)! || a.name.localeCompare(b.name));
    }
    if (s === 'name') return [...base].sort((a, b) => a.name.localeCompare(b.name));
    return [...base].sort((a, b) => new Date(b.lastDonationDate).getTime() - new Date(a.lastDonationDate).getTime());
  });

  fmt = formatDate;

  remove(id: string) {
    this.bb.removeDonor(id);
  }

  noop() {}
}
