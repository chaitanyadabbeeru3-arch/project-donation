import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BLOOD_TYPES, type BloodType } from '../../constants/blood-types';
import { BloodBankService } from '../../services/blood-bank.service';

@Component({
  selector: 'app-availability-check',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="rounded-2xl border border-slate-200 bg-white/80 shadow-sm p-5">
      <div class="flex flex-col md:flex-row md:items-end gap-3">
        <div class="flex-1">
          <label class="label">Required Blood Group</label>
          <select class="field" [ngModel]="group()" (ngModelChange)="group.set($event)">
            <option *ngFor="let t of types" [ngValue]="t">{{ t }}</option>
          </select>
        </div>
        <button class="btn-primary h-10 px-5" (click)="check()">Check Availability</button>
      </div>

      <div class="mt-4" *ngIf="checked()">
        <div *ngIf="matches().length > 0; else noMatch">
          <h3 class="text-sm font-semibold text-slate-700 mb-2">Available Donor(s):</h3>
          <ul class="grid sm:grid-cols-2 gap-3">
            <li *ngFor="let d of matches()" class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <div class="flex items-center justify-between">
                <div class="font-semibold text-slate-900">{{ d.name }}</div>
                <span class="inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-semibold bg-rose-50 text-rose-700 border-rose-200">{{ d.bloodGroup }}</span>
              </div>
              <div class="mt-2 text-sm text-slate-700">
                <div><span class="text-slate-500">Phone:</span> {{ d.contactNumber }}</div>
                <div><span class="text-slate-500">Area:</span> {{ d.address }}</div>
              </div>
            </li>
          </ul>
        </div>
        <ng-template #noMatch>
          <div class="rounded-lg border border-amber-200 bg-amber-50 text-amber-900 p-4">
            No donors found for <strong>{{ group() }}</strong>.
            <a href="#add-donor" class="underline font-medium ml-1">Add a new donor</a> with this blood group.
          </div>
        </ng-template>
      </div>
    </section>
  `,
})
export class AvailabilityCheckComponent {
  private bb = inject(BloodBankService);
  types = BLOOD_TYPES;
  group = signal<BloodType>('A+');
  checked = signal(false);
  matches = computed(() => this.bb.donors().filter(d => d.bloodGroup === this.group()));

  check() { this.checked.set(true); }
}
