import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink],
  template: `
    <header class="backdrop-blur supports-[backdrop-filter]:bg-white/60 bg-white/90 sticky top-0 z-40 border-b border-slate-200/70">
      <div class="container mx-auto px-4">
        <div class="flex items-center justify-between py-4">
          <a routerLink="/" class="flex items-center gap-2">
            <span class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary-600 text-white shadow-sm">🩸</span>
            <div class="leading-tight">
              <div class="text-lg font-semibold text-slate-900">Lifeline Blood Bank</div>
              <div class="text-xs text-slate-500 -mt-0.5">Safe. Reliable. Ready.</div>
            </div>
          </a>
          <nav class="hidden md:flex items-center gap-6 text-sm">
            <a routerLink="/" class="text-slate-700 hover:text-primary-700 transition">Dashboard</a>
            <a routerLink="/donors" class="text-slate-700 hover:text-primary-700 transition">Donors</a>
            <a routerLink="/stock" class="text-slate-700 hover:text-primary-700 transition">Stock</a>
          </nav>
          <div class="md:hidden"></div>
        </div>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  brand = input('Lifeline Blood Bank');
}
