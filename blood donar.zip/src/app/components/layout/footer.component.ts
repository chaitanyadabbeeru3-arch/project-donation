import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  template: `
    <footer class="border-t border-slate-200 bg-white/80">
      <div class="container mx-auto px-4 py-6 text-sm text-slate-500 flex flex-col md:flex-row items-center justify-between gap-2">
        <p>&copy; {{ year }} Lifeline Blood Bank. All rights reserved.</p>
        <p class="opacity-80">Made with care for those in need.</p>
      </div>
    </footer>
  `,
})
export class FooterComponent {
  year = new Date().getFullYear();
}
