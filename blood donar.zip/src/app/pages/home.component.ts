import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DonorFormComponent } from '../components/donor/donor-form.component';
import { DonorListComponent } from '../components/donor/donor-list.component';
import { StockGridComponent } from '../components/stock/stock-grid.component';
import { AvailabilityCheckComponent } from '../components/availability/availability-check.component';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, DonorFormComponent, DonorListComponent, StockGridComponent, AvailabilityCheckComponent],
  template: `
    <section class="relative">
      <div class="bg-gradient-to-b from-rose-50 to-white border-b border-rose-100/60">
        <div class="container mx-auto px-4 py-10 lg:py-14">
          <div class="max-w-3xl">
            <h1 class="text-3xl lg:text-4xl font-semibold tracking-tight text-slate-900">
              Blood Bank Management System
            </h1>
            <p class="mt-3 text-slate-600 leading-relaxed">
              Store and manage blood group data, track availability, and maintain a registry of donors with complete details.
              Quickly check stock levels and generate donor lists by blood group or last donation date.
            </p>
          </div>
        </div>
      </div>

      <div class="container mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-6">
          <app-availability-check></app-availability-check>
          <app-stock-grid></app-stock-grid>
          <app-donor-list></app-donor-list>
        </div>
        <div>
          <div id="add-donor" class="rounded-2xl border border-slate-200 bg-white/70 shadow-sm p-5 sticky top-28">
            <app-donor-form></app-donor-form>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class HomePageComponent {}
