import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DonorListComponent } from '../components/donor/donor-list.component';

@Component({
  selector: 'app-donors-page',
  standalone: true,
  imports: [CommonModule, DonorListComponent],
  template: `
    <section class="container mx-auto px-4 py-8">
      <div class="mb-6">
        <h1 class="text-2xl font-semibold text-slate-900">Donor Directory</h1>
        <p class="text-slate-600">Browse and sort registered donors by blood group or last donation date.</p>
      </div>
      <app-donor-list></app-donor-list>
    </section>
  `,
})
export class DonorsPageComponent {}
