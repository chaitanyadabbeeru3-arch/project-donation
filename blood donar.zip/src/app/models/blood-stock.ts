import type { BloodType } from '../constants/blood-types';

export type BloodStock = Record<BloodType, number>;

export const emptyStock = (): BloodStock => ({
  'A+': 0,
  'A-': 0,
  'B+': 0,
  'B-': 0,
  'O+': 0,
  'O-': 0,
  'AB+': 0,
  'AB-': 0,
});
