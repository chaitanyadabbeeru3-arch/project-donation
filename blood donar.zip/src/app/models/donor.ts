import type { BloodType } from '../constants/blood-types';

export interface Donor {
  id: string;
  name: string;
  age: number;
  contactNumber: string;
  address: string;
  bloodGroup: BloodType;
  lastDonationDate: string; // ISO string
  notes?: string;
}
