import { Routes } from '@angular/router';
import { HomePageComponent } from './pages/home.component';
import { DonorsPageComponent } from './pages/donors.component';

export const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'donors', component: DonorsPageComponent },
  { path: 'stock', component: HomePageComponent },
  { path: '**', redirectTo: '' },
];
