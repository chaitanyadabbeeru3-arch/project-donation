How to run Node backend (requires Node 18+):
1) cd backend/node
2) npm install
3) npm start  (starts on port 8080)

Endpoints:
- GET    /api/health
- GET    /api/donors?bloodGroup=A_POS|A+&sort=lastDonation|name|bloodGroup
- GET    /api/donors/:id
- POST   /api/donors
- PUT    /api/donors/:id
- DELETE /api/donors/:id

Notes:
- Data is persisted to backend/node/data/donors.json
- bloodGroup values use enum codes like A_POS. The API also accepts labels like A+ and converts them.
