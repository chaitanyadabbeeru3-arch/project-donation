const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const db = require('./db');

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 8080;

app.use(cors());
app.use(express.json());
app.use(morgan('tiny'));

app.get('/api/health', (_req, res) => res.send('ok'));

app.get('/api/donors', (req, res) => {
  const { bloodGroup, sort } = req.query;
  try {
    const rows = db.list({ bloodGroup, sort });
    res.json(rows);
  } catch (e) {
    res.status(400).json({ error: e.message || 'Bad request' });
  }
});

app.get('/api/donors/:id', (req, res) => {
  const row = db.get(req.params.id);
  if (!row) return res.sendStatus(404);
  res.json(row);
});

app.post('/api/donors', (req, res) => {
  try {
    const created = db.create(req.body || {});
    res.status(201).location(`/api/donors/${created.id}`).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message || 'Bad request' });
  }
});

app.put('/api/donors/:id', (req, res) => {
  try {
    const updated = db.update(req.params.id, req.body || {});
    if (!updated) return res.sendStatus(404);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message || 'Bad request' });
  }
});

app.delete('/api/donors/:id', (req, res) => {
  const ok = db.remove(req.params.id);
  if (!ok) return res.sendStatus(404);
  res.sendStatus(204);
});

app.listen(PORT, () => {
  console.log(`Node API listening on :${PORT}`);
});
