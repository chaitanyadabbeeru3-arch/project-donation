const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const DONORS_FILE = path.join(DATA_DIR, 'donors.json');

const GROUPS = ['A_POS','A_NEG','B_POS','B_NEG','O_POS','O_NEG','AB_POS','AB_NEG'];

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DONORS_FILE)) fs.writeFileSync(DONORS_FILE, JSON.stringify({ seq: 0, donors: [] }, null, 2));
}

function readStore() {
  ensureStore();
  try {
    const raw = fs.readFileSync(DONORS_FILE, 'utf8');
    return JSON.parse(raw);
  } catch {
    return { seq: 0, donors: [] };
  }
}

function writeStore(data) {
  ensureStore();
  fs.writeFileSync(DONORS_FILE, JSON.stringify(data, null, 2));
}

function normalizeGroup(g) {
  if (!g) return null;
  const map = {
    'A+':'A_POS','A-':'A_NEG','B+':'B_POS','B-':'B_NEG','O+':'O_POS','O-':'O_NEG','AB+':'AB_POS','AB-':'AB_NEG'
  };
  if (GROUPS.includes(g)) return g;
  return map[g] || null;
}

function list({ bloodGroup, sort }) {
  const store = readStore();
  let arr = [...store.donors];
  if (bloodGroup) {
    const g = normalizeGroup(bloodGroup);
    arr = arr.filter(d => d.bloodGroup === g);
  }
  if (sort === 'name') arr.sort((a,b)=>a.name.localeCompare(b.name));
  else if (sort === 'bloodGroup') {
    const order = new Map(GROUPS.map((t,i)=>[t,i]));
    arr.sort((a,b)=> (order.get(a.bloodGroup)-order.get(b.bloodGroup)) || a.name.localeCompare(b.name));
  } else {
    arr.sort((a,b)=> new Date(b.lastDonationDate||'1970-01-01') - new Date(a.lastDonationDate||'1970-01-01'));
  }
  return arr;
}

function get(id) {
  const store = readStore();
  return store.donors.find(d => d.id === Number(id)) || null;
}

function create(input) {
  const store = readStore();
  const now = new Date().toISOString();
  const bloodGroup = normalizeGroup(input.bloodGroup);
  if (!bloodGroup) throw new Error('Invalid bloodGroup');
  if (!input.name) throw new Error('Name is required');
  const id = ++store.seq;
  const row = {
    id,
    name: String(input.name),
    bloodGroup,
    phoneNumber: input.phoneNumber ? String(input.phoneNumber) : '',
    area: input.area ? String(input.area) : '',
    healthCondition: input.healthCondition ? String(input.healthCondition) : '',
    age: Number.isFinite(Number(input.age)) ? Number(input.age) : null,
    lastDonationDate: input.lastDonationDate ? String(input.lastDonationDate).slice(0,10) : null,
    createdAt: now,
    updatedAt: now,
  };
  store.donors.unshift(row);
  writeStore(store);
  return row;
}

function update(id, patch) {
  const store = readStore();
  const row = store.donors.find(d => d.id === Number(id));
  if (!row) return null;
  if (patch.name !== undefined) row.name = String(patch.name);
  if (patch.bloodGroup !== undefined) {
    const g = normalizeGroup(patch.bloodGroup);
    if (!g) throw new Error('Invalid bloodGroup');
    row.bloodGroup = g;
  }
  if (patch.phoneNumber !== undefined) row.phoneNumber = String(patch.phoneNumber);
  if (patch.area !== undefined) row.area = String(patch.area);
  if (patch.healthCondition !== undefined) row.healthCondition = String(patch.healthCondition);
  if (patch.age !== undefined) row.age = Number.isFinite(Number(patch.age)) ? Number(patch.age) : row.age;
  if (patch.lastDonationDate !== undefined) row.lastDonationDate = patch.lastDonationDate ? String(patch.lastDonationDate).slice(0,10) : null;
  row.updatedAt = new Date().toISOString();
  writeStore(store);
  return row;
}

function remove(id) {
  const store = readStore();
  const idx = store.donors.findIndex(d => d.id === Number(id));
  if (idx === -1) return false;
  store.donors.splice(idx,1);
  writeStore(store);
  return true;
}

module.exports = { list, get, create, update, remove, GROUPS };
