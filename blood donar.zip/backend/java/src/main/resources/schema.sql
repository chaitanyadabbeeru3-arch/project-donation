-- Optional schema for manual DB creation (Postgres-compatible). If you use this, set:
-- spring.jpa.hibernate.ddl-auto=none
-- spring.sql.init.mode=always

CREATE TABLE IF NOT EXISTS donors (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  blood_group VARCHAR(5) NOT NULL,
  phone_number VARCHAR(32),
  area VARCHAR(255),
  health_condition TEXT,
  age INT,
  last_donation_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_donors_blood_group ON donors (blood_group);
CREATE INDEX IF NOT EXISTS idx_donors_last_donation ON donors (last_donation_date DESC);
