package com.lifeline.bloodbank.web.dto;

import com.lifeline.bloodbank.model.BloodGroup;
import com.lifeline.bloodbank.model.Donor;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class DonorDtos {
    public record Create(
            @NotBlank String name,
            @NotNull BloodGroup bloodGroup,
            @Size(max = 32) String phoneNumber,
            @Size(max = 255) String area,
            String healthCondition,
            @Min(0) @Max(120) Integer age,
            LocalDate lastDonationDate
    ) {}

    public record Update(
            String name,
            BloodGroup bloodGroup,
            String phoneNumber,
            String area,
            String healthCondition,
            Integer age,
            LocalDate lastDonationDate
    ) {}

    public record View(
            Long id,
            String name,
            BloodGroup bloodGroup,
            String phoneNumber,
            String area,
            String healthCondition,
            Integer age,
            LocalDate lastDonationDate
    ) {
        public static View from(Donor d) {
            return new View(
                    d.getId(), d.getName(), d.getBloodGroup(), d.getPhoneNumber(), d.getArea(),
                    d.getHealthCondition(), d.getAge(), d.getLastDonationDate()
            );
        }
    }
}
