package com.lifeline.bloodbank.repository;

import com.lifeline.bloodbank.model.BloodGroup;
import com.lifeline.bloodbank.model.Donor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DonorRepository extends JpaRepository<Donor, Long> {
    List<Donor> findByBloodGroupOrderByLastDonationDateDesc(BloodGroup bloodGroup);
}
