package com.lifeline.bloodbank.model;

public enum BloodGroup {
    A_POS("A+"), A_NEG("A-"),
    B_POS("B+"), B_NEG("B-"),
    O_POS("O+"), O_NEG("O-"),
    AB_POS("AB+"), AB_NEG("AB-");

    private final String label;
    BloodGroup(String label) { this.label = label; }
    public String getLabel() { return label; }

    public static BloodGroup fromLabel(String s) {
        return switch (s) {
            case "A+" -> A_POS; case "A-" -> A_NEG;
            case "B+" -> B_POS; case "B-" -> B_NEG;
            case "O+" -> O_POS; case "O-" -> O_NEG;
            case "AB+" -> AB_POS; case "AB-" -> AB_NEG;
            default -> throw new IllegalArgumentException("Unknown group: " + s);
        };
    }
}
