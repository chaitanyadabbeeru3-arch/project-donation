package com.lifeline.bloodbank.web;

import com.lifeline.bloodbank.model.BloodGroup;
import com.lifeline.bloodbank.model.Donor;
import com.lifeline.bloodbank.repository.DonorRepository;
import com.lifeline.bloodbank.web.dto.DonorDtos;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DonorController {
    private final DonorRepository repo;
    public DonorController(DonorRepository repo) { this.repo = repo; }

    @GetMapping("/health")
    public ResponseEntity<String> health() { return ResponseEntity.ok("ok"); }

    @GetMapping("/donors")
    public List<DonorDtos.View> list(@RequestParam(required = false) BloodGroup bloodGroup,
                                     @RequestParam(defaultValue = "lastDonation") String sort) {
        Sort s = switch (sort) {
            case "name" -> Sort.by("name").ascending();
            case "bloodGroup" -> Sort.by("bloodGroup").ascending().and(Sort.by("name"));
            default -> Sort.by("lastDonationDate").descending().and(Sort.by("name"));
        };
        return repo.findAll(s).stream().filter(d -> bloodGroup == null || d.getBloodGroup() == bloodGroup)
                .map(DonorDtos.View::from).toList();
    }

    @GetMapping("/donors/{id}")
    public ResponseEntity<DonorDtos.View> get(@PathVariable Long id) {
        return repo.findById(id).map(DonorDtos.View::from).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/donors")
    public ResponseEntity<DonorDtos.View> create(@Valid @RequestBody DonorDtos.Create in) {
        Donor d = new Donor();
        d.setName(in.name());
        d.setBloodGroup(in.bloodGroup());
        d.setPhoneNumber(in.phoneNumber());
        d.setArea(in.area());
        d.setHealthCondition(in.healthCondition());
        d.setAge(in.age());
        d.setLastDonationDate(in.lastDonationDate());
        Donor saved = repo.save(d);
        return ResponseEntity.created(URI.create("/api/donors/" + saved.getId())).body(DonorDtos.View.from(saved));
    }

    @PutMapping("/donors/{id}")
    public ResponseEntity<DonorDtos.View> update(@PathVariable Long id, @Valid @RequestBody DonorDtos.Update in) {
        return repo.findById(id).map(d -> {
            if (in.name() != null) d.setName(in.name());
            if (in.bloodGroup() != null) d.setBloodGroup(in.bloodGroup());
            if (in.phoneNumber() != null) d.setPhoneNumber(in.phoneNumber());
            if (in.area() != null) d.setArea(in.area());
            if (in.healthCondition() != null) d.setHealthCondition(in.healthCondition());
            if (in.age() != null) d.setAge(in.age());
            if (in.lastDonationDate() != null) d.setLastDonationDate(in.lastDonationDate());
            return ResponseEntity.ok(DonorDtos.View.from(repo.save(d)));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/donors/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
