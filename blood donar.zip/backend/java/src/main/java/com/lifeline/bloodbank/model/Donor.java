package com.lifeline.bloodbank.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "donors")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class Donor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "blood_group", nullable = false, length = 5)
    private BloodGroup bloodGroup;

    @Column(name = "phone_number", length = 32)
    private String phoneNumber;

    @Column(length = 255)
    private String area;

    @Column(name = "health_condition", columnDefinition = "text")
    private String healthCondition;

    @Min(0) @Max(120)
    private Integer age;

    private LocalDate lastDonationDate;

    @CreationTimestamp
    @Column(updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    private Instant updatedAt;
}
