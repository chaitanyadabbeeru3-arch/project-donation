How to run (Java 17 required):
1) cd backend/java
2) ./mvnw spring-boot:run (or: mvn spring-boot:run)

API endpoints:
- GET    /api/health
- GET    /api/donors?bloodGroup=A_POS&sort=lastDonation|name|bloodGroup
- GET    /api/donors/{id}
- POST   /api/donors
- PUT    /api/donors/{id}
- DELETE /api/donors/{id}

JSON example (POST /api/donors):
{
  "name": "Priya Sharma",
  "bloodGroup": "A_POS",
  "phoneNumber": "+1 555-0123",
  "area": "City, State",
  "healthCondition": "Healthy",
  "age": 25,
  "lastDonationDate": "2025-09-01"
}

Angular is already wired to try GET /api/donors and POST /api/donors. If backend is running on a different origin, proxy or set BASE_URL.
